from distutils.core import setup

setup(
    name = 'vtrigU',
    version = '1.4.3',
    description = 'vtrigU',
    author='Vayyar',
    author_email='support@vayyar.com',
    url='http://vayyar.com/',
    classifiers=['Programming Language :: Python :: 2', 'Programming Language :: Python :: 3'],
    py_modules=['vtrigU']  
)
