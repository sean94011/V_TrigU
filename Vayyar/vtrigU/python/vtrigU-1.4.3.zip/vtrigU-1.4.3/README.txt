INSTALL INSTRUCTIONS:

For windows run:
(fill in version number)
> python -m pip install vtrigU-XXX.XXX.XXX.zip

For linux run:
(fill in version number)
> python3 -m pip install vtrigU-XXX.XXX.XXX.tar.gz
